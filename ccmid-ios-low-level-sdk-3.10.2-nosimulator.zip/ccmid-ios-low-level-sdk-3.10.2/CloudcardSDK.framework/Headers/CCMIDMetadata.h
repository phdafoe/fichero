//
//  CCMIDMetadata.h
//  CloudcardCoreAPI
//
//  Created by DOGARU Cristiana - EXT-CF (MORPHO) on 30/03/2016.
//  Copyright © 2016 Dictao. All rights reserved.
//

@interface CCMIDMetadata : NSObject

@property (nonatomic) NSData *apnToken;

@end
