//
//  CCMIDDeleteKeyringTransaction.h
//  CloudcardCoreAPI
//
//  Created by lei_zhang on 10/12/15.
//  Copyright © 2015 Dictao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCMIDTransaction.h"

@interface CCMIDDeleteKeyringTransaction : CCMIDTransaction

@end
